SCOTCH CHAT
======================

This is a demo for a proposed article on [Scotch](https://scotch.io)